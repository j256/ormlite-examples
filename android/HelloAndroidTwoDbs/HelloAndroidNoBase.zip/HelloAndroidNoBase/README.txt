-------------------------------------------------------------------------------------------------------

BACKGROUND:

This is a HelloWorld application similar to HelloAndroid but it does not extend ORMLite's 
OrmLiteBaseActivity class.  This manages the helper on its own.

For more information, see the online documentation on the home page:

   http://ormlite.com/

Enjoy,
Gray Watson

-------------------------------------------------------------------------------------------------------
